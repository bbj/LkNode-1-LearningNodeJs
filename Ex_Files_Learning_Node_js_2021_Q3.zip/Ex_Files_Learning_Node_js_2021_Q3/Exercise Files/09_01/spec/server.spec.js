describe('calc', () => {
    it('should multiply 2 and 2', () => {
        expect(2*2).toBe(5)
    })
})